-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------
-- -------------------------------------------
-- START BACKUP
-- -------------------------------------------
-- -------------------------------------------
-- TABLE `admin_log`
-- -------------------------------------------
DROP TABLE IF EXISTS `admin_log`;
CREATE TABLE IF NOT EXISTS `admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `desc` varchar(255) NOT NULL COMMENT '操作详情',
  `time` int(11) NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- TABLE `auth_assignment`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `idx-auth_assignment-user_id` (`user_id`),
  CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `auth_item`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `auth_item_child`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`) USING BTREE,
  KEY `child` (`child`),
  CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `auth_rule`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `jurisdiction`
-- -------------------------------------------
DROP TABLE IF EXISTS `jurisdiction`;
CREATE TABLE IF NOT EXISTS `jurisdiction` (
  `role_id` int(11) NOT NULL COMMENT '角色id',
  `menu_id` int(11) NOT NULL COMMENT '菜单id'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='权限表';

-- -------------------------------------------
-- TABLE `menu`
-- -------------------------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '路径',
  `title` varchar(255) NOT NULL COMMENT '名称',
  `parent_id` int(11) NOT NULL COMMENT '父id',
  `tree` varchar(255) NOT NULL COMMENT '结构树',
  `level` int(11) NOT NULL COMMENT '水平',
  `icon` varchar(255) DEFAULT '' COMMENT '图标',
  `sort` int(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `flag` tinyint(4) NOT NULL DEFAULT '10' COMMENT '标识\r\n1  : 前台菜单\r\n10: 后台菜单',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态\r\n-1:删除\r\n0 :隐藏\r\n1 :显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- TABLE `migration`
-- -------------------------------------------
DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- TABLE `role`
-- -------------------------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '角色名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '角色描述',
  `parent_id` int(11) NOT NULL DEFAULT '1' COMMENT '父id',
  `tree` varchar(255) NOT NULL DEFAULT '' COMMENT '树形菜单',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态\r\n-1:删除\r\n0 :禁用\r\n1 :启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- TABLE `user`
-- -------------------------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `identity` tinyint(4) NOT NULL COMMENT '1用户\r\n2管理员',
  `status` smallint(6) NOT NULL DEFAULT '10' COMMENT '删除0\r\n禁用9\r\n启用10',
  `head_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '头像',
  `role_id` int(11) NOT NULL DEFAULT '999' COMMENT '角色id',
  `created_at` int(11) NOT NULL COMMENT '创建时间',
  `updated_at` int(11) NOT NULL COMMENT '修改时间',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `verification_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `web_system`
-- -------------------------------------------
DROP TABLE IF EXISTS `web_system`;
CREATE TABLE IF NOT EXISTS `web_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `web_title` varchar(255) NOT NULL COMMENT '网站标题',
  `web_logo` varchar(255) DEFAULT NULL COMMENT '网站logo',
  `web_icp` varchar(255) DEFAULT NULL COMMENT 'icp备案号',
  `web_count_code` text COMMENT '统计代码',
  `seo_title` varchar(255) DEFAULT NULL COMMENT 'seo标题',
  `seo_keyword` varchar(255) DEFAULT NULL COMMENT 'seo关键词',
  `seo_desc` text COMMENT 'seo详情',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- TABLE DATA admin_log
-- -------------------------------------------
INSERT INTO `admin_log` (`id`,`username`,`desc`,`time`) VALUES
('10','二级管理员(admin111)','二级管理员(admin111) 登录了','1605853037');
INSERT INTO `admin_log` (`id`,`username`,`desc`,`time`) VALUES
('11','二级管理员(admin111)','在user 中修改 updated_at,last_login_time 数据','1605853037');



-- -------------------------------------------
-- TABLE DATA auth_assignment
-- -------------------------------------------
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('二级管理员','10','1605669779');
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('二级管理员','15','1605768202');
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('二级管理员','7','1605493589');
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('二级管理员','8','1605665667');
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('二级管理员','9','1605669736');
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('管理员','6','1605493429');



-- -------------------------------------------
-- TABLE DATA auth_item
-- -------------------------------------------
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('default/default/default','2','菜单管理',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/admin-menu','2','后台菜单',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/admin-menu-add','2','增加',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/admin-menu-del','2','删除',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/admin-menu-edit-status','2','状态',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/del-all','2','批量删除',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/edit-sort','2','修改排序',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/frontend-menu','2','前台菜单',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/frontend-menu-add','2','增加',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('menu/frontend-menu-del','2','删除',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('role/index','2','RBAC',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('user/backend-index','2','管理员用户',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('user/frontend-index','2','前台用户',NULL,NULL,'1605493322','1605493322');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('二级管理员','1','负责用户管理的管理员',NULL,NULL,'1605493343','1605493343');
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('管理员','1','超级管理员创建的管理员',NULL,NULL,'1605493322','1605493322');



-- -------------------------------------------
-- TABLE DATA auth_item_child
-- -------------------------------------------
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('二级管理员','default/default/default');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','default/default/default');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/admin-menu');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/admin-menu-add');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/admin-menu-del');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/admin-menu-edit-status');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/del-all');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/edit-sort');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/frontend-menu');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/frontend-menu-add');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','menu/frontend-menu-del');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','role/index');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('二级管理员','user/backend-index');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','user/backend-index');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('二级管理员','user/frontend-index');
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('管理员','user/frontend-index');



-- -------------------------------------------
-- TABLE DATA jurisdiction
-- -------------------------------------------
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','11');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','10');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','9');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','8');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','7');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','6');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','5');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','4');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','3');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','2');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','1');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','22');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','21');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','20');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','18');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','19');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','3');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','23');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','17');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','25');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','24');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','23');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','22');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','21');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','20');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','19');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','18');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','17');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','7');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','6');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','5');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','4');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','2');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','1');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','24');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','8');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','9');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','10');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1044','11');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1045','8');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1045','9');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('1045','10');
INSERT INTO `jurisdiction` (`role_id`,`menu_id`) VALUES
('0','26');



-- -------------------------------------------
-- TABLE DATA menu
-- -------------------------------------------
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('1','default/default/default','菜单管理','0','|_ _ ','1','&#xe62a;','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('2','menu/admin-menu','后台菜单','1','|_ _ _ _ ','2','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('3','menu/frontend-menu','前台菜单','1','|_ _ _ _ ','2','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('4','menu/admin-menu-add','增加','2','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('5','menu/admin-menu-add','编辑','2','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('6','menu/admin-menu-del','删除','2','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('7','menu/admin-menu-edit-status','状态','2','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('8','default/default/default','用户管理','0','|_ _ ','1','&#xe613;','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('9','user/frontend-index','前台用户','8','|_ _ _ _ ','2','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('10','user/backend-index','管理员用户','8','|_ _ _ _ ','2','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('11','role/index','RBAC','26','|_ _ _ _ ','2','&#xe628;','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('19','menu/frontend-menu-add','增加','3','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('17','menu/edit-sort','修改排序','2','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('18','menu/edit-sort','修改排序','3','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('20','menu/frontend-menu-add','编辑','3','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('21','menu/frontend-menu-del','删除','3','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('22','menu/admin-menu-edit-status','状态','3','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('23','menu/del-all','批量删除','2','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('24','menu/del-all','批量删除','3','|_ _ _ _ _ _ ','3','','999','10','1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('25','/index/index/index','一级菜单','0','|_ _ ','1','ddd','999','10','-1');
INSERT INTO `menu` (`id`,`name`,`title`,`parent_id`,`tree`,`level`,`icon`,`sort`,`flag`,`status`) VALUES
('26','/default/default/default','设置','0','|_ _ ','1','','999','10','1');



-- -------------------------------------------
-- TABLE DATA migration
-- -------------------------------------------
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m000000_000000_base','1603329526');
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m130524_201442_init','1603329539');
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m190124_110200_add_verification_token_column_to_user_table','1603329539');
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m140506_102106_rbac_init','1605144910');
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m170907_052038_rbac_add_index_on_auth_assignment_user_id','1605144910');
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m180523_151638_rbac_updates_indexes_without_prefix','1605144910');
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m200409_110543_rbac_update_mssql_trigger','1605144910');



-- -------------------------------------------
-- TABLE DATA role
-- -------------------------------------------
INSERT INTO `role` (`id`,`name`,`describe`,`parent_id`,`tree`,`status`) VALUES
('0','超级管理员','超级管理员','0','','1');
INSERT INTO `role` (`id`,`name`,`describe`,`parent_id`,`tree`,`status`) VALUES
('1045','二级管理员','负责用户管理的管理员','1044','|_ _ _ _ ','1');
INSERT INTO `role` (`id`,`name`,`describe`,`parent_id`,`tree`,`status`) VALUES
('1044','管理员','超级管理员创建的管理员','0','|_ _ ','1');



-- -------------------------------------------
-- TABLE DATA user
-- -------------------------------------------
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('1','admin','SyV0SIQBOFlu7rsmBufwmKhw1t0koAMQ','$2y$13$q798pdrp4xXW1kEX./vcEemFCnksqed29OiEJI3lU9i/999cXAG9W',NULL,'admin123@qq.com','2','10',NULL,'0','1605492257','1605853069','1605853069','127.0.0.1','IQ4-JiXX4cmdNUQW15nZ21t4XNZDlXHX_1605492257');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('6','admin123','5vUNbDgRItHDUV-T82JjPcECR4JJVgpf','$2y$13$lhaWVE1.fhYZCqljIDC70.3oNTf7HTrDBg5ZIw8YZpl8nu8KES/XC',NULL,'admin@qq.com','2','10','/uploads/2020/11/16/8c04e26e57dd7e25217676e0343c0aa5.jpg','1044','1605493429','1605493452','1605493452','127.0.0.1','Zl_j7WzWH6j3LbNnZdpg4xA_yHBKhkQH_1605493429');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('7','admin111','aw1NIViqDQyRvvm2Bgt2f2RdiXnvtLaI','$2y$13$9y6bu9gN4QuZcqdgYKxRiOYrJaMD.WTzIWmdfp473Sm7Vuc3zEFf2',NULL,'admin111@qq.com','2','10','/uploads/2020/11/16/e015ed7746d0c688252f152f2e3dc187.jpg','1045','1605493589','1605853037','1605853037','127.0.0.1','lK5ciZmE8_NEJjyTyMy5rNE_0Dp3xRmR_1605493589');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('8','admin222','3K6N7xBRrEpiC4a3zsFgmc6VbsoEbSfo','$2y$13$1iFAZVkAGYahbr16gP1p5uvv0eFPewSUAn6l5EFemUjEcjubYEVZG',NULL,'amdin222@qq.com','2','10','/uploads/2020/11/18/5929c2835ecc676ddb9191d785afa6e5.jpg','1045','1605665667','1605770879','1605770879','127.0.0.1','zSXP-XRHy6EOGSiDvGmEMhDp-47lZ0Go_1605665667');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('9','admin333','AQbHwq4rAm6n5yCSct8ohHW1N0Bkl1NH','$2y$13$zK.CDZAh9cVvdmFjkqf0GueAItZAXDf7WN61Gr15I/.nkVPHwvCmS',NULL,'admin333@qq.com','2','10','/uploads/2020/11/18/29b34ebb9707f185a9aa0a30a0b07d9c.jpg','1045','1605669736','1605669736','0','','zERWnFWNsLvCUiTXE4Ygji0l2PDBSvnx_1605669736');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('10','user1','ASXTm2fTawZE1L6e0JSPeCtO7MXPQm7Z','$2y$13$ASqESc.yp8vBWO.76xxXVOSZlelhEVrxESh/TquXPI4NF75mshaxi',NULL,'user@qq.com','1','10','/uploads/2020/11/18/dcf0a9481ffb71a18a2d8df50ec75e0e.jpg','1045','1605669779','1605756718','0','','ob5S0-Hl_p3uIsFIBmBrwvn2L4C0HUlg_1605669779');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('11','用户名','UvtqT_VOawo1MMTfoTf2IaccYj-d5eC0','$2y$13$zGiZxLx3B529znbL9xHSpuAlN179rJBpOQEBHUOBQolPzEbpnM8Em',NULL,'yonghu@qq.com','1','10',NULL,'999','1605754816','1605754833','1605754833','127.0.0.1','0033nAYDckyeX325Yu_B0Gt3w1AiFzqX_1605754816');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('12','user','6BphXOYK3dU6dZZzMeLgHizDuFML8lIY','$2y$13$a2V/QKeBAohlXuxzERED6.txlGlD8s.5iGOURqcGH8QT4hHJXwqXi',NULL,'user11@qq.com','1','10','/uploads/2020/11/19/7b23496d5e01a95e1ee2d440b76d5d9c.jpg','1045','1605766924','1605766924','0','','Ak5IUycLiGDs-KbVxHDeTU6-MnUth7qb_1605766924');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('13','user2','6APn93W82ioNM1BrUlPgHtCO6uYc0owy','$2y$13$7u.8rF97MFJPezsc7HRqXuOiIaTp7ThwL6skPcO558jBkTz64eWvy',NULL,'user2@qq.com','1','10','/uploads/2020/11/19/e23ec2eb8fbb21c9db0ecb7f0e965173.jpg','1045','1605767221','1605767221','0','','zDE7X9HZ71cAieWS5tizpTTePtUemXAB_1605767221');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('14','user3','uohK6i2sSGyOijrkGDzAFPDeDqkToG6_','$2y$13$GGnnIx1xON9yAmV/Ide64.A/TLGAarxEYSltltU2WIPuq28Tx56wG',NULL,'user3@qq.com','1','10','/uploads/2020/11/19/e23ec2eb8fbb21c9db0ecb7f0e965173.jpg','1045','1605767255','1605767255','0','','yborgbGPAUESiFRu-hq3FnUdG6EoLbw0_1605767255');
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`identity`,`status`,`head_image`,`role_id`,`created_at`,`updated_at`,`last_login_time`,`last_login_ip`,`verification_token`) VALUES
('15','user4','4rEOhdBt9U97ykIlTobrjiP51_QWIxrC','$2y$13$jmt7Lzdr3Nz6DtTLQmPk7uxy7Z0hhQ9Awne1XysuVZ0ndH5g2hxIm',NULL,'user4@qq.com','1','10','/uploads/2020/11/19/d00d9b6cc2c85c987106428f76ec6539.jpg','1045','1605768202','1605768202','0','','Mkjin-g6o9Pm9Wbp8grVxohAteFem4jl_1605768202');



-- -------------------------------------------
-- TABLE DATA web_system
-- -------------------------------------------
INSERT INTO `web_system` (`id`,`web_title`,`web_logo`,`web_icp`,`web_count_code`,`seo_title`,`seo_keyword`,`seo_desc`) VALUES
('1','rbac管理后台','/uploads/2020/11/18/a4208b4af21c1633bd7976ea87ed9bfb.jpg','','','管理后台','rbac管理后台','注重权限管理的管理后台');



-- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
-- -------------------------------------------
-- -------------------------------------------
-- END BACKUP
-- -------------------------------------------
